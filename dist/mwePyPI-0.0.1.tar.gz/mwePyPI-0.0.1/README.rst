README
======

I'm just testing how to upload a package im PyPI.


Links that I helped me to make this package:
http://python-packaging.readthedocs.io/en/latest/minimal.html
https://www.youtube.com/watch?v=YIdXBq2_RN8

https://www.youtube.com/watch?v=Svk0z3kNwd0 (yes I'm from Brazil)