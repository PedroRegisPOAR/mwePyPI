
def mysum(a, b):
    return a + b
