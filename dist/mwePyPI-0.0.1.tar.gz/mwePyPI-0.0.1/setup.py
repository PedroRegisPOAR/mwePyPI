from setuptools import setup

setup(name='mwePyPI',
      version='0.0.1',
      description='It is a minimal work exemple of a package to be uploaded in PyPI.',
      url='https://github.com/PedroRegisPOAR/mwePyPi',
      author='Pedro Osvaldo Alencar Regis',
      author_email='pedroalencarregis@hotmail.com',
      license='MIT',
      packages=['mwePyPI'],
      zip_safe=False)
