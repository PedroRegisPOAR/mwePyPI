
from mwePyPI.file_with_mysum import mysum

print('It is importing.')
